# QuizAppInAndroidStudio
This repository contains a normal quiz app which stores questions locally . It contains a score view with a horizontal progress bar. At the end of the app it contains a alert dialog box 


![Copy of website to learn android development](https://user-images.githubusercontent.com/64765400/102950884-6a02c080-4480-11eb-8bb1-b6d286c46987.png)
